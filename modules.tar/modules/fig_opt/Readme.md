## fig_opt

An extension of FIG format. Options inside Fig/FigObj
comments (compatible with old mapsoft)

-----------
## Changelog:

2019.05.20 V.Zavjalov 1.0:
- First version
