VMAP2 -- new storage for vector map objects.

* Classes for in-memory storage, with geospatial indices
* Option for BerkleyDB storage (also with geospatial indices)
* Text format for Git storage
* Import/export of other formats (MP, FIG, VMAP1, Shape, ...)


