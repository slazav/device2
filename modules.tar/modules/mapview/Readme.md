This is GUI for mapsoft viewer (ms2view program).

* `mapview.h` -- main class

* `am*` -- "action modes", menu entries.

* `action_manager` -- class for switching action modes and delivering mouse clicks to them.

* `w_*` -- Widgets. See also `examples/widgets` program.

* `dlg_*` -- Dialogs. See also `examples/dialogs` program.

* `panel*` -- Viewer panels.

* `css.h`
